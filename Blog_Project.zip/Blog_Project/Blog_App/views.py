from django.shortcuts import render
from rest_framework.response import Response
from .serializers import * 
from rest_framework.views import APIView
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.exceptions import AuthenticationFailed
from django.contrib.auth import authenticate,logout
from rest_framework.permissions import IsAuthenticated
from django.db.models import Q
# from django.core.paginator import Paginator
from rest_framework.authentication import SessionAuthentication



class PublicView_Blog(APIView):

    def get(self, request):
        try: 
            blogs = BlogPost.objects.all().order_by('?')

            if request.GET.get('search'):
                search = request.GET.get('search')
                blogs = blogs.filter(Q(title__icontains = search) | Q(content__icontains = search))

            # page_number = request.GET.get('page' , 1)
            # paginator = Paginator(blogs,1)
            serializer = BlogSerializer(blogs, many=True)

            return Response({
                        'data' : serializer.data,
                        'message' : 'Blog Fetched Successfully....'
                },status=status.HTTP_201_CREATED)

        except Exception as e:
            print(e)
            return Response({
                        'data' : serializer.data,
                        'message' : 'Blog Fetched Successfully....'
                },status=status.HTTP_404_NOT_FOUND)


class RegisterView(APIView):

    def post(self, request):
        try:
            serializer = RegisterSerializer(data=request.data)

            if not serializer.is_valid():
                return Response({
                    'data' : serializer.errors,
                    'message' : 'Something went wrong...'
                },status=status.HTTP_400_BAD_REQUEST) 

            serializer.save()

            return Response({
                    'data' : {},
                    'message' : 'User Registered Successfully....'
                },status=status.HTTP_201_CREATED) 
        
        except Exception as e:
            return Response({
                    'data' : {},
                    'message' : 'Exception Raised....'
            },status=status.HTTP_404_NOT_FOUND) 


class LoginView(APIView):
    
    def post(self, request):
        try:
            serializer = LoginSerializer(data=request.data)
            if not serializer.is_valid():
                return Response({
                    'data': serializer.errors,
                    'message': 'Validation error...'
                }, status=status.HTTP_400_BAD_REQUEST)

            username = serializer.validated_data.get('username')
            password = serializer.validated_data.get('password')
            user = authenticate(username=username, password=password)

            if user is not None:
                return Response({
                    'data': {},
                    'message': 'Login Successful....'
                }, status=status.HTTP_200_OK)
            else:
                raise AuthenticationFailed('Invalid Credentials....')

        except AuthenticationFailed as e:
            return Response({
                'data': {},
                'message': str(e)
            }, status=status.HTTP_401_UNAUTHORIZED)
        except Exception as e:
            return Response({
                'data': {},
                'message': 'Login Exception Raised....'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class BlogView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try: 
            blogs = BlogPost.objects.filter(user = request.user)

            if request.GET.get('search'):
                search = request.GET.get('search')
                blogs = blogs.filter(Q(title__icontains = search) | Q(content__icontains = search))

            serializer = BlogSerializer(blogs, many=True)

            return Response({
                        'data' : serializer.data,
                        'message' : 'Blog Fetched Successfully....'
                },status=status.HTTP_201_CREATED)

        except Exception as e:
            print(e)
            return Response({
                        'data' : serializer.data,
                        'message' : 'Blog Fetched Successfully....'
                },status=status.HTTP_404_NOT_FOUND)


    def post(self, request):
        
        try: 
            data = request.data 
            data['user'] = request.user.id 

            serializer = BlogSerializer(data = data)

            if not serializer.is_valid():

                return Response({
                    'data':serializer.errors,
                    'message': 'Something went wrong...'

                }, status=status.HTTP_400_BAD_REQUEST)

            serializer.save()

            return Response({
                    'data' : serializer.data,
                    'message' : 'Blog Posted Successfully....'
                },status=status.HTTP_201_CREATED) 

        except Exception as e:
            print(e)

            return Response({
                'data':{},
                'message': 'Exception Raised in Blog'
            }, status=status.HTTP_401_UNAUTHORIZED)


    def patch(self, request):

        try:
            data = request.data
            blog = BlogPost.objects.filter(uid = data.get('uid'))
            print(blog)

            if not blog.exists():
                print("not")
                return Response({
                'data':{},
                'message': "Invalid blog UUID..."
            }, status=status.HTTP_404_NOT_FOUND)

            if request.user != blog[0].user:
                print("if")
                return Response({
                'data':{},
                'message': 'Unauthorized user...'
            }, status=status.HTTP_401_UNAUTHORIZED)

            serializer = BlogSerializer(blog[0], partial=True, data=data)
            if not serializer.is_valid():
                return Response({
                    'data' : serializer.errors,
                    'message' : 'Something went wrong...'
                },status=status.HTTP_400_BAD_REQUEST) 

            serializer.save()

            return Response({
                    'data' : {},
                    'message' : 'Blogs Updated Successfully....'
                },status=status.HTTP_200_OK) 

        except Exception as e:
            print(e)
            return Response({
                    'data' : {},
                    'message' : 'Exception Raised....'
                },status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request):

        try:
            data = request.data
            blog = BlogPost.objects.filter(uid = data.get('uid'))
            print(blog)

            if not blog.exists():
                print("not")
                return Response({
                'data':{},
                'message': "Invalid blog UUID..."
            }, status=status.HTTP_404_NOT_FOUND)

            if request.user != blog[0].user:
                print("if")
                return Response({
                'data':{},
                'message': 'Unauthorized user...'
            }, status=status.HTTP_401_UNAUTHORIZED)

            blog[0].delete()

            return Response({
                    'data' : {},
                    'message' : 'Blogs Deleted Successfully....'
                },status=status.HTTP_200_OK) 

        except Exception as e:
            print(e)
            return Response({
                'data':{},
                'message': "Invalid blog UUID..."
            }, status=status.HTTP_404_NOT_FOUND)



class LogoutView(APIView):
    def post(self, request):
        try:
            logout(request)
            
            return Response({
                'data': {},
                'message': 'Logout Successful.'
            }, status=status.HTTP_200_OK)

        except Exception as e:
            print(e)
            return Response({
                'data': {},
                'message': 'Logout Exception Raised....'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)